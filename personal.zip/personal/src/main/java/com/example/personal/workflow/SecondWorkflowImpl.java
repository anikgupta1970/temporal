package com.example.personal.workflow;

import io.temporal.workflow.Workflow;

public class SecondWorkflowImpl implements SecondWorkflow {

    @Override
    public String process(String name) {
        Workflow.sleep(3000);
        return "Processed " + name;
    }
}
