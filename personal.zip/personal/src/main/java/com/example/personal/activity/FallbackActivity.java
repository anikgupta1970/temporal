package com.example.personal.activity;

import io.temporal.activity.ActivityInterface;
import io.temporal.activity.ActivityMethod;

@ActivityInterface
public interface FallbackActivity {

    @ActivityMethod
    String fallback(String name);
}
