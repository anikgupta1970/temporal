package com.example.personal.controller;

import com.example.personal.workflow.MainWorkflow;
import io.temporal.client.WorkflowClient;
import io.temporal.client.WorkflowOptions;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;


@RestController
public class WorkflowController {

    private final WorkflowClient workflowClient;

    public WorkflowController(WorkflowClient workflowClient) {
        this.workflowClient = workflowClient;
    }

    @GetMapping("/start")
    public String startWorkflow() {

        MainWorkflow workflow =
                workflowClient.newWorkflowStub(
                        MainWorkflow.class,
                        WorkflowOptions.newBuilder()
                                .setTaskQueue("demo-task-queue")
                                .setWorkflowId("main-workflow-" + UUID.randomUUID())
                                .build()
                );

        return workflow.run("Main");
    }


}
