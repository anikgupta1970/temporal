package com.example.personal.activity;

public class FirstActivityImpl implements FirstActivity {
    private int attempt = 0;

    @Override
    public String doActivity(String name) {
        attempt++;
        System.out.println("Attempt: " + attempt);
        //if (attempt < 3) {
            throw new RuntimeException("Simulated failure");
        //}
        //System.out.println("Calling external system...");
        //return "Hello " + name;
    }
}
