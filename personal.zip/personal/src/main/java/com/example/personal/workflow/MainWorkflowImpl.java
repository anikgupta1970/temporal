package com.example.personal.workflow;

import com.example.personal.activity.FallbackActivity;
import com.example.personal.activity.FirstActivity;
import io.temporal.activity.ActivityOptions;
import io.temporal.common.RetryOptions;
import io.temporal.failure.ActivityFailure;
import io.temporal.workflow.ChildWorkflowOptions;
import io.temporal.workflow.Workflow;

import java.time.Duration;

public class MainWorkflowImpl implements MainWorkflow {


    private final FirstActivity firstActivity =
            Workflow.newActivityStub(
                    FirstActivity.class,
                    ActivityOptions.newBuilder()
                            .setStartToCloseTimeout(Duration.ofSeconds(5))
                            .setRetryOptions(
                                    RetryOptions.newBuilder()
                                            .setInitialInterval(Duration.ofSeconds(1))
                                            .setMaximumInterval(Duration.ofSeconds(10))
                                            .setMaximumAttempts(3)
                                            .build()
                            )
                            .build()
            );

    private final FallbackActivity fallbackActivity =
            Workflow.newActivityStub(
                    FallbackActivity.class,
                    ActivityOptions.newBuilder()
                            .setStartToCloseTimeout(Duration.ofSeconds(5))
                            .build()
            );
    private final SecondWorkflow secondWorkflow =
            Workflow.newChildWorkflowStub(
                    SecondWorkflow.class,
                    ChildWorkflowOptions.newBuilder()
                            .setWorkflowId("child-workflow-" + Workflow.randomUUID())
                            .build()
            );


    @Override
    public String run(String name) {

        try {
            String result1 = firstActivity.doActivity("activityDone");
            String result2 = secondWorkflow.process("child");
            return result1 + " | " + result2;
        } catch (ActivityFailure e) {
            Workflow.getLogger(MainWorkflowImpl.class)
                    .info("Primary activity failed. Executing fallback...");
            return fallbackActivity.fallback(name);
        }
    }

}
