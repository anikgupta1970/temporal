package com.example.personal.workflow;

import io.temporal.workflow.WorkflowInterface;
import io.temporal.workflow.WorkflowMethod;

@WorkflowInterface
public interface MainWorkflow {

    @WorkflowMethod
    String run(String name);
}
