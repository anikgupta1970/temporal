package com.example.personal.workflow;

import io.temporal.workflow.WorkflowInterface;
import io.temporal.workflow.WorkflowMethod;

@WorkflowInterface
public interface SecondWorkflow {

    @WorkflowMethod
    String process(String name);
}
