package com.example.personal.worker;

import com.example.personal.activity.FallbackActivityImpl;
import com.example.personal.activity.FirstActivityImpl;
import com.example.personal.workflow.MainWorkflowImpl;
import com.example.personal.workflow.SecondWorkflowImpl;
import io.temporal.client.WorkflowClient;
import io.temporal.worker.Worker;
import io.temporal.worker.WorkerFactory;

import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Component;


@Component
public class TemporalWorkerStarter {

    private final WorkflowClient workflowClient;

    public TemporalWorkerStarter(WorkflowClient workflowClient) {
        this.workflowClient = workflowClient;
    }

    @PostConstruct
    public void startWorker() {

        WorkerFactory factory = WorkerFactory.newInstance(workflowClient);

        Worker worker = factory.newWorker("demo-task-queue");

        worker.registerWorkflowImplementationTypes(
                MainWorkflowImpl.class,
                SecondWorkflowImpl.class

        );
        worker.registerActivitiesImplementations(
                new FirstActivityImpl(),
                new FallbackActivityImpl()
        );

        factory.start();

        System.out.println("Temporal Worker Started...");
    }
}
