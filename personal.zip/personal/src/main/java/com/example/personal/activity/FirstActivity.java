package com.example.personal.activity;

import io.temporal.activity.ActivityInterface;
import io.temporal.activity.ActivityMethod;

@ActivityInterface
public interface FirstActivity {

    @ActivityMethod
    String doActivity(String name);
}
