package com.example.personal.activity;

public class FallbackActivityImpl implements FallbackActivity {

    @Override
    public String fallback(String name) {
        return "Fallback executed for " + name;
    }
}
