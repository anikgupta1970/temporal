package com.example.personal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonalApplicationTests {

	@Test
	void contextLoads() {
	}

}
